--
-- PostgreSQL database dump
--

\restrict 7ra5btIrMPJI3WD2lhcyxSAfix4cNdaWB0BpVy6xEjBKXk6GU3HHtt5UrEw2vrW

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_tokens; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.access_tokens (
    id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    token_preview character varying(16) NOT NULL,
    course_id character varying(64) NOT NULL,
    payment_id character varying(128),
    created_by_tg_id bigint NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    used_by_tg_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone
);


ALTER TABLE public.access_tokens OWNER TO admin;

--
-- Name: access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.access_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_tokens_id_seq OWNER TO admin;

--
-- Name: access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.access_tokens_id_seq OWNED BY public.access_tokens.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO admin;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.courses (
    id character varying(64) NOT NULL,
    title character varying(128) NOT NULL,
    description text,
    invite_link character varying(512),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.courses OWNER TO admin;

--
-- Name: payment_event_logs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.payment_event_logs (
    id integer NOT NULL,
    payment_id character varying(128),
    event_type character varying(64) NOT NULL,
    status character varying(32) NOT NULL,
    course_ids text,
    telegram_id bigint,
    token_id bigint,
    message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment_event_logs OWNER TO admin;

--
-- Name: payment_event_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.payment_event_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_event_logs_id_seq OWNER TO admin;

--
-- Name: payment_event_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.payment_event_logs_id_seq OWNED BY public.payment_event_logs.id;


--
-- Name: token_courses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.token_courses (
    id integer NOT NULL,
    token_id integer NOT NULL,
    course_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_courses OWNER TO admin;

--
-- Name: token_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.token_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.token_courses_id_seq OWNER TO admin;

--
-- Name: token_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.token_courses_id_seq OWNED BY public.token_courses.id;


--
-- Name: user_course_accesses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.user_course_accesses (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    course_id character varying(64) NOT NULL,
    token_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_course_accesses OWNER TO admin;

--
-- Name: user_course_accesses_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.user_course_accesses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_course_accesses_id_seq OWNER TO admin;

--
-- Name: user_course_accesses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.user_course_accesses_id_seq OWNED BY public.user_course_accesses.id;


--
-- Name: access_tokens id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.access_tokens ALTER COLUMN id SET DEFAULT nextval('public.access_tokens_id_seq'::regclass);


--
-- Name: payment_event_logs id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payment_event_logs ALTER COLUMN id SET DEFAULT nextval('public.payment_event_logs_id_seq'::regclass);


--
-- Name: token_courses id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_courses ALTER COLUMN id SET DEFAULT nextval('public.token_courses_id_seq'::regclass);


--
-- Name: user_course_accesses id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_course_accesses ALTER COLUMN id SET DEFAULT nextval('public.user_course_accesses_id_seq'::regclass);


--
-- Data for Name: access_tokens; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.access_tokens (id, token_hash, token_preview, course_id, payment_id, created_by_tg_id, is_used, used_by_tg_id, created_at, used_at) FROM stdin;
1	17fa5f9153af9e54745070c9fbe3d4ad2eba1a6fba07b0edbc09c02160c00ef8	RiUStN...vqg8	python-backend	payment-123	0	t	692080442	2026-05-22 21:06:40.024667+00	2026-05-22 21:07:10.054261+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.alembic_version (version_num) FROM stdin;
0001_initial_schema
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.courses (id, title, description, invite_link, is_active, created_at) FROM stdin;
python-backend	Python Backend	Backend course	https://t.me/+example_python	t	2026-05-22 21:05:30.591993+00
csharp-aspnet	C# ASP.NET Core	ASP.NET Core course	https://t.me/+example_csharp	t	2026-05-22 21:06:10.802183+00
\.


--
-- Data for Name: payment_event_logs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.payment_event_logs (id, payment_id, event_type, status, course_ids, telegram_id, token_id, message, created_at) FROM stdin;
1	payment-123	token_create	success	python-backend,csharp-aspnet	\N	1	\N	2026-05-22 21:06:40.024667+00
3	payment-123	token_activate	success	python-backend,csharp-aspnet	692080442	1	\N	2026-05-22 21:07:10.045708+00
\.


--
-- Data for Name: token_courses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.token_courses (id, token_id, course_id, created_at) FROM stdin;
1	1	python-backend	2026-05-22 21:06:40.024667+00
2	1	csharp-aspnet	2026-05-22 21:06:40.024667+00
\.


--
-- Data for Name: user_course_accesses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.user_course_accesses (id, telegram_id, course_id, token_id, created_at) FROM stdin;
1	692080442	python-backend	1	2026-05-22 21:07:10.045708+00
2	692080442	csharp-aspnet	1	2026-05-22 21:07:10.045708+00
\.


--
-- Name: access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.access_tokens_id_seq', 1, true);


--
-- Name: payment_event_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.payment_event_logs_id_seq', 3, true);


--
-- Name: token_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.token_courses_id_seq', 2, true);


--
-- Name: user_course_accesses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.user_course_accesses_id_seq', 2, true);


--
-- Name: access_tokens access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.access_tokens
    ADD CONSTRAINT access_tokens_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: payment_event_logs payment_event_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payment_event_logs
    ADD CONSTRAINT payment_event_logs_pkey PRIMARY KEY (id);


--
-- Name: token_courses token_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_courses
    ADD CONSTRAINT token_courses_pkey PRIMARY KEY (id);


--
-- Name: token_courses token_courses_token_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_courses
    ADD CONSTRAINT token_courses_token_id_course_id_key UNIQUE (token_id, course_id);


--
-- Name: user_course_accesses user_course_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_course_accesses
    ADD CONSTRAINT user_course_accesses_pkey PRIMARY KEY (id);


--
-- Name: user_course_accesses user_course_accesses_telegram_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_course_accesses
    ADD CONSTRAINT user_course_accesses_telegram_id_course_id_key UNIQUE (telegram_id, course_id);


--
-- Name: ix_access_tokens_course_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ix_access_tokens_course_id ON public.access_tokens USING btree (course_id);


--
-- Name: ix_access_tokens_payment_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX ix_access_tokens_payment_id ON public.access_tokens USING btree (payment_id);


--
-- Name: ix_access_tokens_token_hash; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX ix_access_tokens_token_hash ON public.access_tokens USING btree (token_hash);


--
-- Name: ix_token_courses_course_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ix_token_courses_course_id ON public.token_courses USING btree (course_id);


--
-- Name: ix_token_courses_token_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ix_token_courses_token_id ON public.token_courses USING btree (token_id);


--
-- Name: ix_user_course_accesses_course_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ix_user_course_accesses_course_id ON public.user_course_accesses USING btree (course_id);


--
-- Name: ix_user_course_accesses_telegram_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX ix_user_course_accesses_telegram_id ON public.user_course_accesses USING btree (telegram_id);


--
-- Name: token_courses token_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_courses
    ADD CONSTRAINT token_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE RESTRICT;


--
-- Name: token_courses token_courses_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.token_courses
    ADD CONSTRAINT token_courses_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.access_tokens(id) ON DELETE CASCADE;


--
-- Name: user_course_accesses user_course_accesses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_course_accesses
    ADD CONSTRAINT user_course_accesses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE RESTRICT;


--
-- Name: user_course_accesses user_course_accesses_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_course_accesses
    ADD CONSTRAINT user_course_accesses_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.access_tokens(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 7ra5btIrMPJI3WD2lhcyxSAfix4cNdaWB0BpVy6xEjBKXk6GU3HHtt5UrEw2vrW

